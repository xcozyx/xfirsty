#ifndef CLICOMMON_H
#define CLICOMMON_H

void showdbiflist(const int mode);

#endif

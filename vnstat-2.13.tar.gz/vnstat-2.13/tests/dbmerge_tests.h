#ifndef DBMERGE_TESTS_H
#define DBMERGE_TESTS_H

void add_dbmerge_tests(Suite *s);

#endif

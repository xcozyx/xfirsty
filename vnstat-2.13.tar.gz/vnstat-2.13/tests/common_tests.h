#ifndef COMMON_TESTS_H
#define COMMON_TESTS_H

void add_common_tests(Suite *s);

#endif
